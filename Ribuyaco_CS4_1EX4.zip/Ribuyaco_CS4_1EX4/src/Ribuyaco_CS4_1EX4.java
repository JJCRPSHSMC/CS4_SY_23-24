import java.util.Scanner;

public class Ribuyaco_CS4_1EX4 {
    public static void main(String[] args) {
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");

        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);

        int roundsToWin = 2;
        boolean progRun = true;
        Scanner sc = new Scanner(System.in);

        //int random = (int) Math.floor(Math.random()*3) + 1;

        do {
            System.out.println("Welcome to Rock, Paper, Scissors! Please choose an option:");
            System.out.println("1. Start Game\r\n2. Change # of Rounds\r\n3. Exit Application");
            int menuResp = sc.nextInt();
            int userRoundsWon = 0;
            int compRoundsWon = 0;

            switch(menuResp) {
                case 1:
                    do {
                        System.out.println("This match will be first to " + roundsToWin + " wins.");
                        int random = (int) Math.floor(Math.random() * 3) + 1;
                        Move compResp = null;
                        String crDisp = null;
                            switch(random) {
                                case 1: compResp = rock; crDisp = rock.getName();
                                break;
                                case 2: compResp = paper; crDisp = paper.getName();
                                break;
                                case 3: compResp = scissors; crDisp = scissors.getName();
                                break;
                            }
                        System.out.println("The computer has selected its move. Select your move:");
                        System.out.println("1. " + rock.getName() + "\r\n2. " + paper.getName() + "\r\n3. " + scissors.getName());
                        int resp = sc.nextInt();
                        Move userResp = null;
                        String urDisp = null;
                            switch(resp) {
                                case 1: userResp = rock; urDisp = rock.getName();
                                break;
                                case 2: userResp = paper; urDisp = paper.getName();
                                break;
                                case 3: userResp = scissors; urDisp = scissors.getName();
                                break;
                            }

                        String winner = null;
                        int outCome = Move.compareMoves(compResp, userResp);
                            switch(outCome) {
                                case 0: compRoundsWon += 1; winner = "Computer";
                                break;
                                case 1: userRoundsWon += 1; winner = "Player";
                                break;
                                case 2: winner = "Nobody";
                                break;
                            }

                        System.out.println("\r\n\r\n\r\n" + "Player chose " + urDisp + ". Computer chose " + crDisp);
                        System.out.println(winner + " wins the round.");
                        System.out.println("Player: " + userRoundsWon + " - Computer: " + compRoundsWon + "\r\n");

                    } while ((userRoundsWon < roundsToWin) && (compRoundsWon < roundsToWin));
                break;

                case 2:
                    System.out.println("Please input new # of rounds: ");
                    roundsToWin = sc.nextInt();
                    System.out.println("New setting saved.\r\n");
                break;

                case 3:
                    progRun = false;
                    System.out.println("Thank you for playing!");
                break;

            }
        } while (progRun == true);

    }
}